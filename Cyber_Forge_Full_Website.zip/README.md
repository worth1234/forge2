# Cyber Forge — Complete Website

## What's included

- Fully integrated Cyber Forge course website and interactive learning map
- 14 cybersecurity courses, lessons, and quizzes
- Cyber Tutor: built-in course Q&A, with optional external Gemini API settings
- Cyber Labs: five training missions, a simulated Windows-like desktop, progress, XP, and badges
- Forge OS: community-themed operations dashboard, The Midnight Alert case, and simulated terminal commands such as `forge status` and `forge badges`
- Animated upward-moving star background, dark navy / light blue / white visual theme
- Warning that the full desktop simulator is best used on desktop/laptop computers, not phones/tablets
- Co-founder credit for Wareth Al Buhmaid and Hasan Darwish

## Open locally

Open `index.html` in Chrome, Edge, Safari, or Firefox. No install or hosting is required to try the built-in educational site.

## Publish on the web

Upload `index.html` as the root page of a static website such as GitHub Pages, Cloudflare Pages, or Netlify. See your host's current deployment steps. If using a custom domain, configure DNS and HTTPS through the host.

## Important limitations

- Forge OS is an interactive browser simulation, **not** an actual Windows 11 virtual machine or a fully functioning Linux VM. Simulated command results are educational examples and do not execute on a user's computer.
- Browser progress and XP are stored locally in each browser. Shared cross-device accounts require a backend.
- The Cyber Tutor's offline course guidance works without a server, but a real generative-AI connection requires a configured provider. Do not publicly ship an API secret embedded in front-end code; use a backend proxy for production.
- The site has been checked for embedded JavaScript syntax and archive consistency. Browser compatibility depends on the user's environment.

This bundle contains the full standalone website (no separately hosted page assets required for the core layout).
